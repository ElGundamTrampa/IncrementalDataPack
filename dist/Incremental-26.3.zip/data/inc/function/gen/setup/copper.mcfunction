execute positioned ~ ~0.5 ~ summon minecraft:item_display run function inc:gen/display/copper
tag @s add inc.visual2
